insert into team (teamid,teamname) values (1,'India');
insert into team (teamid,teamname) values (2,'UK');
insert into team (teamid,teamname) values (3,'USA');
insert into team (teamid,teamname) values (4,'JAPAN');
insert into team (teamid,teamname) values (5,'CANADA');