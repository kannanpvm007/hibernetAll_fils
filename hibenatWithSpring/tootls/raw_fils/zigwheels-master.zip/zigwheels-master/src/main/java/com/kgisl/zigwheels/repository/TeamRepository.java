package com.kgisl.zigwheels.repository;

import com.kgisl.zigwheels.model.Team;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 * TeamRepository
 */
public interface TeamRepository extends JpaRepository<Team,Long>{

    
}