package com.kgisl.zigwheels.service;

import java.util.List;

import com.kgisl.zigwheels.model.Car;

/**
 * CarService
 * 
 * @param <Car>
 */
public interface CarService {

    public List<Car> getCars();
}