package com.kgisl.zigwheels;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZigwheelsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZigwheelsApplication.class, args);
	}

}
