zigwheels

Travis build

[![Build Status](https://travis-ci.org/manimekalai8797/zigwheels.svg?branch=master)](https://travis-ci.org/manimekalai8797/zigwheels)

codecoverage code cov

[![codecov](https://codecov.io/gh/manimekalai8797/zigwheels/branch/master/graph/badge.svg)](https://codecov.io/gh/manimekalai8797/zigwheels)    

